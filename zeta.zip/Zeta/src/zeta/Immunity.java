/**
 * 
 */
package zeta;

/**
 * @author cloud
 *
 */
public class Immunity extends Agent
{
	
	public Immunity()
	{
		Logger.enterFunction("Immunity.Immunity()");
		
		name = "Immunity";
		effectTime = 4;
		
		Logger.leaveFunction();
		
	}
	
	public Immunity(Virologist virologistUnderEffect, String name, int remainingTime, int effectTime) 
	{
		Logger.enterFunction("Immunity.Immunity(String name, int remainingTime, int effectTime)");
		
		this.virologistUnderEffect = virologistUnderEffect;
		this.name = name;
		this.remainingTime = remainingTime;
		this.effectTime = effectTime;
		
		Logger.leaveFunction();
	}
	
	@Override
	public void step()
	{
		Logger.enterFunction("Immunity.step()");
		
		if(virologistUnderEffect != null)
		{
			virologistUnderEffect.setImmunity(true);
			setRemainingTime(remainingTime - 1);
			if(remainingTime == 0) 
			{
				virologistUnderEffect.setImmunity(false);
//				virologistUnderEffect.set
			}
			
			//timer removeSteppable function call
		}		
		Logger.leaveFunction();
	}
	
}
