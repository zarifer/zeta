package zeta;
import java.io.IOException;
import java.util.ArrayList;

public class Virologist {
	private Game game;
	private boolean immunity;
	private boolean paralyzed;
	private boolean dancing;
	private Field standingField;
	private ArrayList<Agent> agents;
	private ArrayList<Gloves> wearedGloves;
	private ArrayList<Sack> wearedSack;
	private ArrayList<Cloak> wearedCloak;
	private Inventory inventory;
	
	public Virologist(Game game, Field standingField)
	{
		Logger.enterFunction("Virologist.Virologist(Game game, Field standingField)");
		
		init(game, standingField);
		
		Logger.leaveFunction();
	}
	
	public Virologist(Game game, boolean immunity, boolean paralyzed, boolean dancing,
			Field standingField, ArrayList<Agent> agents, ArrayList<Gloves> wearedGloves,
			ArrayList<Sack> wearedSack, ArrayList<Cloak> wearedCloak, Inventory inventory)
	{
		Logger.enterFunction("Virologist.Virologist(Game game, boolean immunity, boolean paralyzed, boolean dancing, Field standingField, ArrayList<Agent> agents, ArrayList<Gloves> wearedGloves, ArrayList<Sack> wearedSack, ArrayList<Cloak> wearedCloak, Inventory inventory)");
		
		boolean bValid = game != null && standingField != null && agents != null && wearedGloves != null
				&& wearedSack != null && wearedCloak != null && inventory != null;
		
		if (bValid)
		{
			bValid = wearedGloves.size() + wearedSack.size() + wearedCloak.size() <= 3;
		}
		
		if (bValid)
		{
			this.game = game;
			this.immunity = immunity;
			this.paralyzed = paralyzed;
			this.dancing = dancing;
			this.standingField = standingField;
			this.agents = agents;
			this.wearedGloves = wearedGloves;
			this. wearedSack = wearedSack;
			this.wearedCloak = wearedCloak;
			this.inventory = inventory;
		}
		else
		{
			init(game, standingField);
		}
		
		Logger.leaveFunction();
	}
	
	private void init(Game game, Field standingField)
	{
		Logger.enterFunction("Virologist.init(Game game, Field standingField)");
		
		if (game != null)
		{
			this.game = game;
		}
		else
		{
			this.game = new Game();
		}
		
		immunity = false;
		paralyzed = false;
		dancing = false;
		
		if (standingField != null)
		{
			this.standingField = standingField;
		}
		else
		{
			this.standingField = new Field();
		}
		
		agents = new ArrayList<Agent>();
		wearedGloves = new ArrayList<Gloves>();
		wearedSack = new ArrayList<Sack>();
		wearedCloak = new ArrayList<Cloak>();
		inventory = new Inventory();
		
		Logger.leaveFunction();
		
	}
	
	//-------------------BEGIN SETTER FUNCTIONS-------------------
	
	public void setImmunity(boolean bImmune)
	{
		Logger.enterFunction("Virologist.setImmunity(boolean bImmune)");
		
		this.immunity = bImmune;
		
		Logger.leaveFunction();
	}
	
	public void setParalyzed(boolean bParalyzed)
	{
		Logger.enterFunction("Virologist.setParalyzed(boolean bParalyzed)");
		
		this.paralyzed = bParalyzed;
		
		Logger.leaveFunction();
	}
	
	public void setDancing(boolean bDancing)
	{
		Logger.enterFunction("Virologist.setDancing(boolean bDancing)");
		
		this.dancing = bDancing;
		
		Logger.leaveFunction();
	}
	
	public void setStandingField(Field f)
	{
		Logger.enterFunction("Virologist.setStandingField(Field f)");
		
		if (f != null)
		{
			this.standingField = f;
		}
		
		Logger.leaveFunction();
	}
	
	//-------------------END SETTER FUNCTIONS-------------------
	
	//-------------------BEGIN GETTER FUNCTIONS-------------------
	
	public boolean getImmunity()
	{
		Logger.enterFunction("Virologist.getImmunity()");		
		Logger.leaveFunction();
		
		return immunity;
	}
	
	public boolean getParalyzed()
	{
		Logger.enterFunction("Virologist.getParalyzed()");		
		Logger.leaveFunction();
		
		return paralyzed;
	}
	
	public boolean getDancing()
	{
		Logger.enterFunction("Virologist.getDancing()");		
		Logger.leaveFunction();
		
		return dancing;
	}
	
	public Field getStandingField()
	{
		Logger.enterFunction("Virologist.getStandingField()");		
		Logger.leaveFunction();
		
		return standingField;
	}
	
	public Inventory getInventory()
	{
		Logger.enterFunction("Virologist.getInventory()");		
		Logger.leaveFunction();
		
		return inventory;
	}
	
	//-------------------END GETTER FUNCTIONS-------------------
	
	public void step()
	{
		Logger.enterFunction("Virologist.step()");
		
		for (int i=0; i<agents.size(); i++)
		{
			Agent a = agents.get(i);
			a.setRemainingTime(a.getRemainingTime() - 1);
			
			if (a.getRemainingTime() == 0)
			{
				agents.remove(i);
				System.out.println("Agent expired and removed.");
			}
			else
			{
				agents.set(i, a);
			}
		}
		
		Logger.leaveFunction();
	}
	
	public void equipGloves()
	{
		Logger.enterFunction("Virologist.equipGloves(Gloves g)");
		
		if(paralyzed)
		{
			System.out.println("Virologist paralized. Can not perform action.");
		}
		else if (dancing)
		{
			System.out.println("Virologist is under vitusdance effect. Can not perform action.");
		}
		else if (canEquipEq())
		{
			Gloves glovesToEquip = inventory.removeGloves();
			if (glovesToEquip == null)
			{
				System.out.println("Can not equip null object.");
			}
			else
			{
				wearedGloves.add(glovesToEquip);
				System.out.println("Gloves equipped.");
			}
		}
		
		Logger.leaveFunction();
	}
	
	public void equipSack()
	{
		Logger.enterFunction("Virologist.equipSacks(Sack s)");
		
		if(paralyzed)
		{
			System.out.println("Virologist paralized. Can not perform action.");
		}
		else if (dancing)
		{
			System.out.println("Virologist is under vitusdance effect. Can not perform action.");
		}
		else if (canEquipEq())
		{
			Sack sackToEquip = inventory.removeSack();
			if (sackToEquip == null)
			{
				System.out.println("Can not equip null object.");
			}
			else
			{
				wearedSack.add(sackToEquip);
				System.out.println("Sack equipped.");
				int currentMaxMaterial = inventory.getMaxMaterial();
				inventory.setMaxMaterial(currentMaxMaterial + sackToEquip.getCapacity());
			}
		}
		
		Logger.leaveFunction();
	}
	
	public void equipCloak()
	{
		Logger.enterFunction("Virologist.equipCloak(Cloak c)");
		
		if(paralyzed)
		{
			System.out.println("Virologist paralized. Can not perform action.");
		}
		else if (dancing)
		{
			System.out.println("Virologist is under vitusdance effect. Can not perform action.");
		}
		else if (canEquipEq())
		{
			Cloak cloakToEquip = inventory.removeCloak();
			if (cloakToEquip == null)
			{
				System.out.println("Can not equip null object.");
			}
			else
			{
				wearedCloak.add(cloakToEquip);
				System.out.println("Cloak equipped.");
			}
		}
		
		Logger.leaveFunction();
	}
	
	public boolean defense(Virologist vFr, Agent a)
	{
		Logger.enterFunction("Virologist.defense(Virologist vFr, Agent a)");
		
		boolean bDefenseSucceed = false;
		if(paralyzed)
		{
			System.out.println("Virologist paralized. Can not perform action.");
		}
		else if (dancing)
		{
			System.out.println("Virologist is under vitusdance effect. Can not perform action.");
		}
		else if (a == null || vFr == null)
		{
			System.out.println("Null object detected, automatically defended.");
			bDefenseSucceed = true;
		}
		else
		{
			if (wearedGloves.size() > 0)
			{
				Gloves g = wearedGloves.get(0);
				if (g.wannaUse())
				{
					wearedGloves.remove(0);
					System.out.println("1 gloves was taken off.");
					g.use(vFr, this, a);
					bDefenseSucceed = true;
				}
				
			}
			
			if (bDefenseSucceed)
			{
				
			}
			else
			{
				for(int i = 0; i < wearedCloak.size(); i++)
				{
					Cloak c = wearedCloak.get(i);
					bDefenseSucceed = c.evade();
					if (bDefenseSucceed)
					{
						wearedCloak.remove(i);
						System.out.println("Evade succeed, cloak removed.");
						break;
					}
				}
			}
		}
		
		Logger.leaveFunction();
		return bDefenseSucceed;
	}
	
	public void takeOffGloves()
	{
		Logger.enterFunction("Virologist.takeOffGloves()");
		
		if(paralyzed)
		{
			System.out.println("Virologist paralized. Can not perform action.");
		}
		else if (dancing)
		{
			System.out.println("Virologist is under vitusdance effect. Can not perform action.");
		}
		else
		{
			takeOffGloves(inventory);
		}
		
		Logger.leaveFunction();
	}
	
	private boolean takeOffGloves(Inventory inv)
	{
		Logger.enterFunction("Virologist.takeOffGloves(Inventory inv)");
		
		boolean bFound = false;
		if (wearedGloves.size() > 0)
		{
			Gloves glovesToRemove = wearedGloves.remove(0);
			System.out.println("1 gloves was taken off.");
			inv.addGloves(glovesToRemove);
			bFound = true;
		}
		else
		{
			System.out.println("No gloves found to take off.");
		}
		
		Logger.leaveFunction();
		return bFound;
	}
	
	public void takeOffSack()
	{
		Logger.enterFunction("Virologist.takeOffSack()");
		
		if(paralyzed)
		{
			System.out.println("Virologist paralized. Can not perform action.");
		}
		else if (dancing)
		{
			System.out.println("Virologist is under vitusdance effect. Can not perform action.");
		}
		else
		{
			takeOffSack(inventory);
		}
		
		Logger.leaveFunction();
	}
	
	private boolean takeOffSack(Inventory inv)
	{
		Logger.enterFunction("Virologist.takeOffSack(Inventory inv)");
		
		boolean bFound = false;
		if (wearedSack.size() > 0)
		{
			Sack SackToUnequip = wearedSack.remove(0);
			
			System.out.println("1 sack was taken off.");
			
			inv.addSack(SackToUnequip);
			
			int currentMaxMaterial = inventory.getMaxMaterial();
			inventory.setMaxMaterial(currentMaxMaterial - SackToUnequip.getCapacity());
			bFound = true;
		}
		else
		{
			System.out.println("No sack found to take off.");
		}
		
		Logger.leaveFunction();
		return bFound;
	}
	
	public void takeOffCloak()
	{
		Logger.enterFunction("Virologist.takeOffCloak()");
		
		if(paralyzed)
		{
			System.out.println("Virologist paralized. Can not perform action.");
		}
		else if (dancing)
		{
			System.out.println("Virologist is under vitusdance effect. Can not perform action.");
		}
		else
		{
			takeOffCloak(inventory);
		}
		
		Logger.leaveFunction();
	}
	
	private boolean takeOffCloak(Inventory inv)
	{
		Logger.enterFunction("Virologist.takeOffCloak(Inventory inv)");
		
		boolean bFound = false;
		if (wearedCloak.size() > 0)
		{
			Cloak cloakToRemove = wearedCloak.remove(0);
			System.out.println("1 cloak was taken off.");
			inv.addCloak(cloakToRemove);
			bFound = true;
		}
		else
		{
			System.out.println("No gloves found to take off.");
		}
		
		Logger.leaveFunction();
		return bFound;
	}
	
	//it is enough to give over the GCode here, don't need to use the Lab object inside this function
	public void touchy(GCode gc)
	{
		Logger.enterFunction("Virologist.touchy(GCode gc)");
		
		if(paralyzed)
		{
			System.out.println("Virologist paralized. Can not perform action.");
		}
		else if (dancing)
		{
			System.out.println("Virologist is under vitusdance effect. Can not perform action.");
		}
		else if (gc != null)
		{
			int currentGCodeCount = inventory.learnGCode(gc);
			if (currentGCodeCount == Game.getMaxGCode())
			{
				game.endGame(this);
			}
		}
		
		Logger.leaveFunction();
	}
	
	
	public void createAgent(GCode gc)
	{
		Logger.enterFunction("Virologist.createAgent(GCode g)");
		
		if(paralyzed)
		{
			System.out.println("Virologist paralized. Can not perform action.");
		}
		else if (dancing)
		{
			System.out.println("Virologist is under vitusdance effect. Can not perform action.");
		}
		else if (gc != null)
		{
			Agent a = gc.create(this);
			if (a != null)
			{
				agents.add(a);
				System.out.println("New agent added to the list of created agents.");
			}
		}
		
		Logger.leaveFunction();
	}

	public void addAgent(Agent a)
	{
		Logger.enterFunction("Virologist.addAgent(Agent a)");
		
		if ( a!= null) 
		{
			agents.add(a);
		}
		
		Logger.leaveFunction();
	}
	
	public void attack(Virologist vTo, Agent a)
	{
		Logger.enterFunction("Virologist.attack(Virologist vTo, Agent a)");
		
		if(paralyzed)
		{
			System.out.println("Virologist paralized. Can not perform action.");
		}
		else if (dancing)
		{
			System.out.println("Virologist is under vitusdance effect. Can not perform action.");
		}
		else if (a == null || vTo == null)
		{
			System.out.println("Can not use null object to attack.");
		}
		else if(this.standingField != vTo.standingField)
		{
			System.out.println("Attacker and attacked virologist have to stand on the same field.");
		}
		else
		{
			boolean bDefenseSuccessful = vTo.assaulted(this, a);
			
			if (!bDefenseSuccessful && vTo.getParalyzed())
			{
				if (wannaSteal())
				{
					vTo.stealBy(this);
				}
			}			
		}
		
		Logger.leaveFunction();
	}
	
	private boolean wannaSteal() {
		Logger.enterFunction("Virologist.wannaSteal()");
		
		boolean bSteal = false;
		
		if(paralyzed)
		{
			System.out.println("Virologist paralized. Can not perform action.");
		}
		else if (dancing)
		{
			System.out.println("Virologist is under vitusdance effect. Can not perform action.");
		}
		else
		{
		
			System.out.println("Paralyzed virologist found. Do you want to Steal? (Y/N)");
			
			int input=' ';
			while(true) 
			{
				try 
				{
					input = System.in.read();
				}
				catch (IOException e) 
				{
					e.printStackTrace();
				}
				
				if((char)input=='Y' || (char)input=='y' || (char)input=='N' || (char)input=='n')
					break;
			}
			if((char)input=='y' || (char)input=='Y') 
			{
				bSteal = true;
				System.out.println("Player choosed to steal.");
			}
			else 
			{
				System.out.println("Player choosed to skip stealing.");
			}
		}
		
		Logger.leaveFunction();
		return bSteal;
	}

	public void move(Field f, boolean bEmittedByUser)
	{
		Logger.enterFunction("Virologist.move(Field f, boolean bEmittedByUser)");
		
		if(paralyzed)
		{
			System.out.println("Virologist paralized. Can not perform action.");
		}
		else if (dancing && bEmittedByUser)
		{
			System.out.println("Virologist is under vitusdance effect. Can not perform action.");
		}
		else if (!standingField.getNeighbours().contains(f))
		{
			System.out.println("Virologist can only move to a field, which is neighboar of his current standing field. Can not perform action.");
		}
		else if (f != null)
		{
			f.arrive(this);
		}
		
		Logger.leaveFunction();
	}
	
	public void stealBy(Virologist v)
	{
		Logger.enterFunction("Virologist.stealBy(Virologist v)");
		
		if (v == null)
		{
			System.out.println("Null object can not steal.");
		}
		else if (v.paralyzed)
		{
			System.out.println("Stealer virologist paralized. Can not perform action.");
		}
		else if (v.dancing)
		{
			System.out.println("Stealer virologist is under vitusdance effect. Can not perform action.");
		}
		if(!this.paralyzed)
		{
			System.out.println("The Virologist, who you want to steal from, is not paralized. Can not perform action.");
		}
		else if (this.standingField != v.standingField)
		{
			System.out.println("Only virologists on the same field can perform this action.");
		}
		else
		{
			Inventory stealerInv = v.getInventory();
			
			String objectName = v.chooseObjectToSteal();
			
			boolean bEquippedFound = false;
			
			switch(objectName)
			{
			case "Aminoacid":
				stealerInv.addAmino(inventory.removeAmino());
				break;
			case "Nukleotid":
				stealerInv.addNukleo(inventory.removeNukleo());
				break;
			case "Gloves":
				bEquippedFound = takeOffGloves(stealerInv);
				if (!bEquippedFound)
				{
					stealerInv.addGloves(inventory.removeGloves());
				}
				break;
			case "Sack":
				bEquippedFound = takeOffSack(stealerInv);
				if (!bEquippedFound)
				{
					stealerInv.addSack(inventory.removeSack());
				}
				break;
			case "Cloak":
				bEquippedFound = takeOffCloak(stealerInv);
				if (!bEquippedFound)
				{
					stealerInv.addCloak(inventory.removeCloak());
				}
				break;
			}
		}
		
		Logger.leaveFunction();
	}
	
	public Agent takeAgentToUse(String name)
	{
		Logger.enterFunction("Virologist.takeAgentToUse(String name)");
		
		Agent a = null;
		if (name != null) 
		{
			for (int i=0; i < agents.size(); i++)
			{
				if (agents.get(i).getName() == name)
				{
					a = agents.remove(i);
				}
			}
		}
		
		Logger.leaveFunction();
		return a;
	}
	
	private boolean assaulted(Virologist vFr, Agent a)
	{
		Logger.enterFunction("Virologist.assaulted(Virologist vFr, Agent a)");
		
		boolean bDefenseSucceed = false;
		
		if (getHasEffectedAgent())
		{
			System.out.println("There is already an effective agent on this virologist, skip this action.");
		}
		else if (vFr != null && a != null)
		{
			boolean bDefenseSuccessful = false;
			if (vFr != this)
			{
				bDefenseSuccessful = defense(vFr, a);
			}
			
			if (!bDefenseSuccessful)
			{
				a.setVirologistUnderEffect(this);
				a.setRemainingTime(a.getEffectTime());
				//TODO: add to stepable
			}
		}
		
		Logger.leaveFunction();
		return bDefenseSucceed;
	}
	
	private String chooseObjectToSteal()
	{
		Logger.enterFunction("Virologist.chooseObjectToSteal()");
		
		String objectName = "";
		
		if(paralyzed)
		{
			System.out.println("Virologist paralized. Can not perform action.");
		}
		else if (dancing)
		{
			System.out.println("Virologist is under vitusdance effect. Can not perform action.");
		}
		else
		{
		
			System.out.println("Which object do you want to Steal? (a/n/g/s/c)");
			System.out.println("a - Aminoacid, n - Nukleotid, g - Gloves, s - Sack, c - Cloak");
			
			int input=' ';
			while(true) 
			{
				try 
				{
					input = System.in.read();
				}
				catch (IOException e) 
				{
					e.printStackTrace();
				}
				
				if((char)input=='A' || (char)input=='a' || (char)input=='N' || (char)input=='n'
						|| (char)input=='G' || (char)input=='g' || (char)input=='S' || (char)input=='s'
						|| (char)input=='C' || (char)input=='c')
					break;
			}
			if((char)input=='A' || (char)input=='a') 
			{
				objectName = "Aminoacid";
			}
			else if ((char)input=='N' || (char)input=='n')
			{
				objectName = "Nukleotid";
			}
			else if ((char)input=='G' || (char)input=='g')
			{
				objectName = "Gloves";
			}
			else if ((char)input=='S' || (char)input=='s')
			{
				objectName = "Sack";
			}
			else if ((char)input=='C' || (char)input=='c')
			{
				objectName = "Cloak";
			}

		}
		System.out.println("Player choosed " + objectName);
		
		Logger.leaveFunction();
		return objectName;
	}
	
	private boolean canEquipEq()
	{
		Logger.enterFunction("Virologist.canEquipEq()");
		
		boolean canEquip = wearedGloves.size() + wearedSack.size() + wearedCloak.size() < 3;
		if (!canEquip)
		{
			System.out.println("Can not equip more equipment.");
		}
		
		Logger.leaveFunction();
		return canEquip;
	}
	
	public boolean getHasEffectedAgent()
	{
		Logger.enterFunction("Virologist.getHasEffectedAgent()");
		Logger.leaveFunction();
		
		return paralyzed && dancing && immunity;
	}
	
	public void showEndGame(Virologist v)
	{
		Logger.enterFunction("Virologist.showEndGame(Virologist v)");
		
		if (v != null)
		{
			if (v != this)
			{
				System.out.println("Game over! You lost.");
			}
			else
			{
				System.out.println("Congratulation! You won the game.");
			}
		}
		
		Logger.leaveFunction();
	}
}
