package zeta;

public class Logger 
{
	private static int deepness;
	
	public static void enterFunction(String logMessage) 
	{
		deepness++;
		for(int i=0; i < deepness; i++) 
		{
			System.out.print("\t");
		}
		System.out.println(logMessage);
	}
	
	public static void leaveFunction() 
	{
		if(deepness > 0) 
		{
			deepness--;
		}
	}
}
