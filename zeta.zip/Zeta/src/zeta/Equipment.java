/**
 * 
 */
package zeta;

/**
 * @author cloud
 *
 */
public abstract class Equipment {
	public Equipment() 
	{
		Logger.enterFunction("Equipment.Equipment()");
		
		//TODO
		
		Logger.leaveFunction();
	}
	
	public abstract void pickUp(Virologist v);

}
