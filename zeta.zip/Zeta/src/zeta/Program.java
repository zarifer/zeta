package zeta;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.ArrayList;

public class Program {
	
	public static void CreatingParalysis() {
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		GCode gc = new GCode("Paralysis",1,1);
		v.getInventory().learnGCode(gc);
		v.createAgent(gc);
		v.getInventory().addAmino(new Aminoacid());
		v.getInventory().addNukleo(new Nukleotid());
		v.createAgent(gc);
	}
	
	public static void CreatingVitusDance() {
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		GCode gc = new GCode("VitusDance",2,1);
		for (int i=0; i<3; i++)
			v.getInventory().addAmino(new Aminoacid());
		for (int i=0; i<4; i++)
			v.getInventory().addNukleo(new Nukleotid());
		v.getInventory().learnGCode(gc);
		v.createAgent(gc);
	}
	
	public static void CreatingImmunity() {
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		GCode gc = new GCode("Immunity",2,4);
		for (int i=0; i<3; i++)
			v.getInventory().addAmino(new Aminoacid());
		for (int i=0; i<4; i++)
			v.getInventory().addNukleo(new Nukleotid());
		v.getInventory().learnGCode(gc);
		v.createAgent(gc);
	}
	
	public static void TakeOffGlovesBackToInventoty() {
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		Gloves glov = new Gloves();
		v.getInventory().addGloves(glov);
		v.equipGloves();
		v.takeOffGloves();
	}
	
	public static void TakeOffCloakBackToInventoty() {
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		Cloak cloak = new Cloak();
		v.getInventory().addCloak(cloak);
		v.equipCloak();
		v.takeOffCloak();
	}
	
	public static void TakeOffSackBackToInventoty() {
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		Sack sack = new Sack();
		v.getInventory().addSack(sack);
		v.equipSack();
		v.takeOffSack();
	}
	
	public static void TakeOffGlovesAndDrop() {
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		Gloves glov = new Gloves();
		v.getInventory().addGloves(glov);
		v.equipGloves();
		Inventory inv = v.getInventory();
		for(int i=0; i<5;i++) {
			Sack s = new Sack();
			inv.addSack(s);
		}
		v.takeOffGloves();
	}
	
	public static void TakeOffCloakAndDrop() {
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		Cloak cloak = new Cloak();
		v.getInventory().addCloak(cloak);
		v.equipCloak();
		Inventory inv = v.getInventory();
		for(int i=0; i<5;i++) {
			Sack s = new Sack();
			inv.addSack(s);
		}
		v.takeOffCloak();
	}
	
	public static void TakeOffSackAndDrop() {
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		Sack sack = new Sack();
		v.getInventory().addSack(sack);
		v.equipSack();
		Inventory inv = v.getInventory();
		for(int i=0; i<5;i++) {
			Gloves glov = new Gloves();
			inv.addGloves(glov);
		}
		v.takeOffSack();
	}
	
	public static void UseAgentOnVirologistWhoHasGlovesAndCloakAndParalyzed(){
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		Gloves glov=new Gloves();
		v2.getInventory().addGloves(glov);
		v2.equipGloves();
		Cloak cloak=new Cloak();
		v2.getInventory().addCloak(cloak);
		v2.equipCloak();
		v2.setParalyzed(true);
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseAgentWhileParalyzed() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		v1.setParalyzed(true);
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseParalysisOnNotImmunVirologist() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		v2.setImmunity(false);
		Paralysis o=new Paralysis();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseImmunityOnNotImmunVirologist() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		v2.setImmunity(false);
		Immunity i=new Immunity();
		v1.addAgent(i);
		v1.attack(v2, i);
	}
	
	public static void UseOblivionOnNotImmunVirologist() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		v2.setImmunity(false);
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseAgentOnVirologistWhoHasCloak() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		Cloak cloak=new Cloak();
		v2.getInventory().addCloak(cloak);
		v2.equipCloak();
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseAgentOnVirologistWhoHasImmunity() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		v2.setImmunity(true);
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseAgentOnVirologistWhoHasGloves() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		Gloves glov=new Gloves();
		v2.getInventory().addGloves(glov);
		v2.equipGloves();
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseAgentOnVirologistWhoHasGlovesAndCloak() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		Gloves glov=new Gloves();
		v2.getInventory().addGloves(glov);
		v2.equipGloves();
		Cloak cloak=new Cloak();
		v2.getInventory().addCloak(cloak);
		v2.equipCloak();
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseAgentOnVirologistWhoHasGlovesAndIHaveToo() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		Gloves glov2=new Gloves();
		v2.getInventory().addGloves(glov2);
		v2.equipGloves();
		Gloves glov1=new Gloves();
		v1.getInventory().addGloves(glov1);
		v1.equipGloves();
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseAgentOnVirologistWhoHasGlovesAndIHaveCloak() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		Gloves glov=new Gloves();
		v2.getInventory().addGloves(glov);
		v2.equipGloves();
		Cloak cloak=new Cloak();
		v2.getInventory().addCloak(cloak);
		v2.equipCloak();
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseAgentOnVirologistWhoHasGlovesAndIHaveImmunity() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		Gloves glov=new Gloves();
		v2.getInventory().addGloves(glov);
		v2.equipGloves();
		v1.setImmunity(true);
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void SelfuseAgentWhenHasCloak() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Cloak cloak=new Cloak();
		v1.getInventory().addCloak(cloak);
		v1.equipCloak();
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v1, o);
	}
	
	public static void SelfuseAgentWhenHasGloves() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Gloves glov=new Gloves();
		v1.getInventory().addGloves(glov);
		v1.equipGloves();
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v1, o);
	}
	
	public static void SelfuseAgentWhenHasCloakAndGloves() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Cloak cloak=new Cloak();
		v1.getInventory().addCloak(cloak);
		v1.equipCloak();
		Gloves glov=new Gloves();
		v1.getInventory().addGloves(glov);
		v1.equipGloves();
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v1, o);
	}
	
	public static void SelfuseAgentWhenHasNoAgents() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		v1.attack(v1, new Oblivion());
	}
	
	public static void SelfuseAgentWhenParalyzed() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		v1.setParalyzed(true);
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v1, o);
	}
	
	public static void SelfuseAgentWhenHasImmunity() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		v1.setImmunity(true);
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v1, o);
	}
	
	public static void SelfuseOblivion() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v1, o);
	}
	
	public static void SelfuseVitusDance() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		VitusDance o=new VitusDance();
		v1.addAgent(o);
		v1.attack(v1, o);
	}
	
	public static void SelfuseImmunity() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Immunity o=new Immunity();
		v1.addAgent(o);
		v1.attack(v1, o);
	}
	
	public static void SelfuseParalysis() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Paralysis o=new Paralysis();
		v1.addAgent(o);
		v1.attack(v1, o);
	}
	
	public static void MoveWhileDancing() {
		Game g = new Game();
		Field f1 = new Field();
		Virologist v1 = new Virologist(g,f1);
		v1.setDancing(true);
		Field f2 = new Field();
		v1.move(f2, true);
	}
	
	public static void MoveToNotNeighbour() {
		Game g = new Game();
		Field f1 = new Field();
		Virologist v1 = new Virologist(g,f1);
		Field f2 = new Field();
		v1.move(f2, true);
	}
	
	public static void StealFromNonParalyzed()
	{
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		v2.stealBy(v1);
	}
	
	public static void StealAsParalyzed()
	{
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g, false, true, false,
				f, new ArrayList<Agent>(), new ArrayList<Gloves>(),
				new ArrayList<Sack>(), new ArrayList<Cloak>(), new Inventory());
		v1.stealBy(v2);
	}
	
	public static void StealFromPoorGuy()
	{
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g, false, true, false,
				f, new ArrayList<Agent>(), new ArrayList<Gloves>(),
				new ArrayList<Sack>(), new ArrayList<Cloak>(), new Inventory());
		v2.stealBy(v1);
		
	}
	
	public static void StealFromAminoGuy()
	{
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		ArrayList<Aminoacid> aminoList = new ArrayList<Aminoacid>();
		aminoList.add(new Aminoacid());
		Inventory inv = new Inventory(new ArrayList<Gloves>(), new ArrayList<Sack>(), new ArrayList<Cloak>(),
				new ArrayList<GCode>(), aminoList, new ArrayList<Nukleotid>());
		Virologist v2 = new Virologist(g, false, true, false,
				f, new ArrayList<Agent>(), new ArrayList<Gloves>(),
				new ArrayList<Sack>(), new ArrayList<Cloak>(), inv);
		v2.stealBy(v1);
		
	}
	
	public static void StealFromNukleoGuy()
	{
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		ArrayList<Nukleotid> nukleolist = new ArrayList<Nukleotid>();
		nukleolist.add(new Nukleotid());
		Inventory inv = new Inventory(new ArrayList<Gloves>(), new ArrayList<Sack>(), new ArrayList<Cloak>(),
				new ArrayList<GCode>(), new ArrayList<Aminoacid>(), nukleolist);
		Virologist v2 = new Virologist(g, false, true, false,
				f, new ArrayList<Agent>(), new ArrayList<Gloves>(),
				new ArrayList<Sack>(), new ArrayList<Cloak>(), inv);
		v2.stealBy(v1);
		
	}
	
	public static void StealFromNukleoGuyButIAmFull()
	{
		Game g = new Game();
		Field f = new Field();
		ArrayList<Nukleotid> nukleolist1 = new ArrayList<Nukleotid>();
		for (int i=0; i<20; i++)
			nukleolist1.add(new Nukleotid());
		Inventory inv1 = new Inventory(new ArrayList<Gloves>(), new ArrayList<Sack>(), new ArrayList<Cloak>(),
				new ArrayList<GCode>(), new ArrayList<Aminoacid>(), nukleolist1);
		Virologist v1 = new Virologist(g, false, false, false,
				f, new ArrayList<Agent>(), new ArrayList<Gloves>(),
				new ArrayList<Sack>(), new ArrayList<Cloak>(), inv1);
		ArrayList<Nukleotid> nukleolist2 = new ArrayList<Nukleotid>();
		nukleolist2.add(new Nukleotid());
		Inventory inv2 = new Inventory(new ArrayList<Gloves>(), new ArrayList<Sack>(), new ArrayList<Cloak>(),
				new ArrayList<GCode>(), new ArrayList<Aminoacid>(), nukleolist2);
		Virologist v2 = new Virologist(g, false, true, false,
				f, new ArrayList<Agent>(), new ArrayList<Gloves>(),
				new ArrayList<Sack>(), new ArrayList<Cloak>(), inv2);
		v2.stealBy(v1);
		
	}
	
	public static void StealFromGuyWithGlovesInStorage()
	{
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		ArrayList<Gloves> gloves = new ArrayList<Gloves>();
		gloves.add(new Gloves());
		Inventory inv = new Inventory(gloves, new ArrayList<Sack>(), new ArrayList<Cloak>(),
				new ArrayList<GCode>(), new ArrayList<Aminoacid>(), new ArrayList<Nukleotid>());
		Virologist v2 = new Virologist(g, false, true, false,
				f, new ArrayList<Agent>(), new ArrayList<Gloves>(),
				new ArrayList<Sack>(), new ArrayList<Cloak>(), inv);
		v2.stealBy(v1);
	}
	
	public static void StealFromGuyWithGlovesEquipped()
	{
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		ArrayList<Gloves> gloves = new ArrayList<Gloves>();
		gloves.add(new Gloves());
		Virologist v2 = new Virologist(g, false, true, false,
				f, new ArrayList<Agent>(), gloves,
				new ArrayList<Sack>(), new ArrayList<Cloak>(), new Inventory());
		v2.stealBy(v1);
	}
	
	public static void StealFromGuyWithCloakInStorage()
	{
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		ArrayList<Cloak> cloacks = new ArrayList<Cloak>();
		cloacks.add(new Cloak());
		Inventory inv = new Inventory(new ArrayList<Gloves>(), new ArrayList<Sack>(), cloacks,
				new ArrayList<GCode>(), new ArrayList<Aminoacid>(), new ArrayList<Nukleotid>());
		Virologist v2 = new Virologist(g, false, true, false,
				f, new ArrayList<Agent>(), new ArrayList<Gloves>(),
				new ArrayList<Sack>(), new ArrayList<Cloak>(), inv);
		v2.stealBy(v1);
	}
	
	public static void StealFromGuyWithCloakEquipped()
	{
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		ArrayList<Cloak>  cloacks = new ArrayList<Cloak>();
		cloacks.add(new Cloak());
		Virologist v2 = new Virologist(g, false, true, false,
				f, new ArrayList<Agent>(), new ArrayList<Gloves>(),
				new ArrayList<Sack>(), cloacks, new Inventory());
		v2.stealBy(v1);
	}
	
	public static void StealFromGuyWithEmptySackEquipped()
	{
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		
		ArrayList<Nukleotid> nukleolist = new ArrayList<Nukleotid>();
		for (int i=0; i<8; i++)
			nukleolist.add(new Nukleotid());
		ArrayList<Aminoacid> aminolist = new ArrayList<Aminoacid>();
		for (int i=0; i<9; i++)
			aminolist.add(new Aminoacid());
		ArrayList<Sack> sacks = new ArrayList<Sack>();
		sacks.add(new Sack());
		Inventory inv = new Inventory(new ArrayList<Gloves>(), sacks, new ArrayList<Cloak>(),
				new ArrayList<GCode>(), aminolist, nukleolist);
		
		Virologist v2 = new Virologist(g, false, false, false,
				f, new ArrayList<Agent>(), new ArrayList<Gloves>(),
				new ArrayList<Sack>(), new ArrayList<Cloak>(), inv);
		
		v2.equipSack();
		v2.setParalyzed(true);
		
		v2.stealBy(v1);
	}
	
	public static void StealFromGuyWithStuffInSackEquipped()
	{
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		
		ArrayList<Nukleotid> nukleolist = new ArrayList<Nukleotid>();
		for (int i=0; i<12; i++)
			nukleolist.add(new Nukleotid());
		ArrayList<Sack> sacks = new ArrayList<Sack>();
		sacks.add(new Sack());
		Inventory inv = new Inventory(new ArrayList<Gloves>(), sacks, new ArrayList<Cloak>(),
				new ArrayList<GCode>(), new ArrayList<Aminoacid>(), nukleolist);
		
		Virologist v2 = new Virologist(g, false, false, false,
				f, new ArrayList<Agent>(), new ArrayList<Gloves>(),
				new ArrayList<Sack>(), new ArrayList<Cloak>(), inv);
		
		v2.equipSack();
		
		inv = v2.getInventory();
		
		for (int i=0; i<12; i++)
			inv.addAmino(new Aminoacid());
		
		v2.setParalyzed(true);
		v2.stealBy(v1);
	}
	
	public static void StealFromGuyWithSackInStorage()
	{
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		ArrayList<Sack> sacks = new ArrayList<Sack>();
		sacks.add(new Sack());
		Inventory inv = new Inventory(new ArrayList<Gloves>(), sacks, new ArrayList<Cloak>(),
				new ArrayList<GCode>(), new ArrayList<Aminoacid>(), new ArrayList<Nukleotid>());
		Virologist v2 = new Virologist(g, false, true, false,
				f, new ArrayList<Agent>(), new ArrayList<Gloves>(),
				new ArrayList<Sack>(), new ArrayList<Cloak>(), inv);
		v2.stealBy(v1);
	}

	public static void VirologistMoves()
	{
		Game g = new Game();
		Field f1 = new Field();
		Field f2 = new Field();
		Virologist v = new Virologist(g, f1);
		Field.setNeighbours(f1, f2);
		v.move(f2, true);
	}

	public static void VirologistMovesParalyzed()
	{ 
		Game g = new Game();
		Field f1 = new Field();
		Field f2 = new Field();
		Virologist v = new Virologist(g, f1);
		v.setParalyzed(true);
		v.move(f2, true);
	}
	
	public static void ParalyzedTouchy()
	{ 
		Game g = new Game();
		Lab l = new Lab(null, 0, 0);
		Virologist v = new Virologist(g, l);
		GCode gc = new GCode("Oblivion", 3, 5);
		v.setParalyzed(true);
		v.touchy(gc);
	}
	
	public static void NewGCTouchy()
	{ 
		Game g = new Game();
		Lab l = new Lab(null, 0, 0);
		Virologist v = new Virologist(g, l);
		GCode gc = new GCode("Oblivion", 3, 5);
		Inventory inv = v.getInventory();
		inv.learnGCode(gc);
		
	}
	
	public static void OldGCTouchy()
	{ 
		Game g = new Game();
		Lab l = new Lab(null, 0, 0);
		Virologist v = new Virologist(g, l);
		GCode gc = new GCode("Oblivion", 3, 5);
		Inventory inv = v.getInventory();
		v.touchy(gc);
		inv.learnGCode(gc);
	}
	
	public static void WinGameByLastTouchy()
	{ 
		Game g = new Game();
		Lab l = new Lab(null, 0, 0);
		Virologist v = new Virologist(g, l);
		GCode gc1 = new GCode("Oblivion", 3, 5);
		GCode gc2 = new GCode("Immunity", 2, 4);
		GCode gc3 = new GCode("Paralysis", 6, 2);
		GCode gc4 = new GCode("VitusDance", 1, 3);
		Inventory inv = v.getInventory();
		inv.learnGCode(gc1);
		inv.learnGCode(gc2);
		inv.learnGCode(gc3);
		inv.learnGCode(gc4);
	}
	
	public static void ParalyzedPickUpMat()
	{ 
		Game g = new Game();
		Storage st = new Storage();
		Virologist v = new Virologist(g, st);
		Nukleotid n = new Nukleotid();
		v.setParalyzed(true);
		n.pickUp(v);
	}
	
	public static void NukleoPickUp()
	{ 
		Game g = new Game();
		Storage st = new Storage();
		Virologist v = new Virologist(g, st);
		Nukleotid n = new Nukleotid();
		n.pickUp(v);
	}
	
	public static void AminoPickUp()
	{ 
		Game g = new Game();
		Storage st = new Storage();
		Virologist v = new Virologist(g, st);
		Aminoacid a = new Aminoacid();
		a.pickUp(v);
	}
	
	public static void FullPickUpMat()
	{ 
		Game g = new Game();
		Storage st = new Storage();
		Virologist v = new Virologist(g, st);
		Nukleotid n = new Nukleotid();
		Inventory inv = v.getInventory();
		for (int i = 0; i <= 20; i++)
		{
			inv.addNukleo(n);
		}
	}
	
	public static void ParalyzedPickUpEq()
	{ 
		Game g = new Game();
		Shelter sh = new Shelter();
		Virologist v = new Virologist(g, sh);
		Cloak c = new Cloak();
		v.setParalyzed(true);
		c.pickUp(v);
	}
	
	public static void GlovesPickUp()
	{ 
		Game g = new Game();
		Shelter sh = new Shelter();
		Virologist v = new Virologist(g, sh);
		Gloves gl = new Gloves();
		gl.pickUp(v);
	}
	
	public static void CloakPickUp()
	{ 
		Game g = new Game();
		Shelter sh = new Shelter();
		Virologist v = new Virologist(g, sh);
		Cloak c = new Cloak();
		c.pickUp(v);
	}
	
	public static void SackPickUp()
	{ 
		Game g = new Game();
		Shelter sh = new Shelter();
		Virologist v = new Virologist(g, sh);
		Sack s = new Sack();
		s.pickUp(v);
	}
	
	public static void FullPickUpEq()
	{ 
		Game g = new Game();
		Storage st = new Storage();
		Virologist v = new Virologist(g, st);
		Cloak c = new Cloak();
		Inventory inv = v.getInventory();
		for (int i = 0; i <= 5; i++)
		{
			inv.addCloak(c);
		}
	}
	
	public static void CreatingOblivion()
	{
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		GCode gc = new GCode("Oblivion",1,1);
		v.getInventory().learnGCode(gc);
		v.createAgent(gc);
	}
	
	public static void DanceWhileMove()
	{
		Game g = new Game();
		Field f1 = new Field();
		Field f2 = new Field();
		Virologist v = new Virologist(g, f1);
		v.setDancing(true);
		v.move(f2, true);
	}
	
	public static void MoveToNowhere()
	{
		Game g = new Game();
		Field f1 = new Field();
		Field f2 = null;
		Virologist v = new Virologist(g, f1);
		v.move(f2, true);
	}
	
	public static void TakeOnOffEq()
	{
		Game g = new Game();
		Shelter sh = new Shelter();
		Virologist v = new Virologist(g, sh);
		Sack s = new Sack();
		Inventory inv = v.getInventory();
		inv.addSack(s);
		v.equipSack();
		v.takeOffSack();
		
	}
	
	public static void UseUnavailableAgent()
	{
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		Paralysis o = null;
		v1.attack(v2, o);
	}
	
	public static void StepParalyzed()
	{
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Agent a = new Paralysis();
		
		a.setVirologistUnderEffect(v1);
		a.setRemainingTime(a.getEffectTime());
		
		while(a.getRemainingTime() != 0)
		{
			a.step();
		}
	}
	
	public static void StepVitusDance()
	{
		Game g = new Game();
		Field f = new Field();
		Field f1 = new Field();
		Field f2 = new Field();
		Field f3 = new Field();
		Field f4 = new Field();
		Field.setNeighbours(f, f1);
		Field.setNeighbours(f, f2);
		Field.setNeighbours(f, f3);
		Field.setNeighbours(f, f4);
		Field.setNeighbours(f1, f2);
		Field.setNeighbours(f1, f3);
		Field.setNeighbours(f3, f2);
		Field.setNeighbours(f3, f4);
		
		Virologist v1 = new Virologist(g,f);
		Agent a = new VitusDance();
		
		a.setVirologistUnderEffect(v1);
		a.setRemainingTime(a.getEffectTime());
		
		while(a.getRemainingTime() != 0)
		{
			a.step();
		}
	}

	public static void StepOblivion()
	{
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Agent a = new Oblivion();
		
		a.setVirologistUnderEffect(v1);
		a.setRemainingTime(a.getEffectTime());
		
		while(a.getRemainingTime() != 0)
		{
			a.step();
		}
	}

	public static void StepImmunity()
	{
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Agent a = new Immunity();
		
		a.setVirologistUnderEffect(v1);
		a.setRemainingTime(a.getEffectTime());
		
		while(a.getRemainingTime() != 0)
		{
			a.step();
		}
	}
	
	public static void main(String[] args) throws IOException
	{
		System.out.println("Zeta Csapat Szkeleton\n");
		System.out.println("Lehets�ges UseCase-k:");
		String str[]= {"b�n�t� �gens k�sz�t�se","t�ncol� �gens k�sz�t�se","v�d� �gens k�sz�t�se","keszty� lev�tel, vissza az inventoryba","k�peny lev�tel, vissza az inventoryba", "zs�k lev�tel, vissza az inventoryba",
			"keszty� lev�tel,de az inventory tele van","k�peny lev�tel,de az inventory tele van", "zs�k lev�tel,de az inventory tele van", "�gens ken�se b�nult k�penyes keszty�s virol�gusra","�gens ken�se m�sra b�nultan",
			"b�n�t� �gens ken�se v�dtelen virol�gusra","v�d� �gens ken�se v�dtelen virol�gusra","felejt� �gens ken�se v�dtelen virol�gusra","�gens ken�se k�penyes virol�gusra","�gens ken�se v�d� �genses virol�gusra",
			"�gens ken�se keszty�s virol�gusra","�gens ken�se k�penyes �s keszty�s virol�gusra","�gens ken�se keszty�s virol�gusra mikor nekem is van keszty�m (nekem legal�bb annyi van, mint neki)",
			"�gens ken�se keszty�s virol�gusra mikor rajtam k�peny van","�gens ken�se keszty�s virol�gusra mikor rajtam v�d� �gens van","�gens magamra ken�se mikor k�peny van rajtam","�gens magamra ken�se mikor keszty� van rajtam",
			"�gens magamra ken�se mikor keszty� �s k�peny van rajtam","�gens magamra ken�se mikor nincs olyan �gensem","�gens ken�se b�nultan �nmag�ra","�gens ken�se magamra v�d��gens hat�sa alatt","b�n�t� �gens ken�se magamra",
			"t�ncol� �gens ken�se magamra","v�d� �gens ken�se magamra","felejt� �gens ken�se magamra", "Mozg�s vitust�nc k�zben", "Mozg�s nem szomsz�dos mez�re", "mozg�s", "mozg�s b�nultan", "labork�d letapogat�sa b�nultan","�j labork�d letapogat�sa","r�gi labork�d letapogat�sa",
				"j�t�k megnyer�se","rakt�rb�l b�nultan anyagfelv�tel","rakt�rb�l nukleotid felv�tele","rakt�rb�l aminosav felv�tele","rakt�rb�l anyagfelv�tel teli t�rol�val","�v�helyr�l eszk�zfelv�tel b�nultan",
				"rakt�rb�l keszty� felv�tele","rakt�rb�l k�peny felv�tele","rakt�rb�l zs�k felv�tele","rakt�rb�l eszk�zfelv�tel teli t�rol�val", "felejt� �gens k�sz�t�se", "mozg�s t�ncol�s k�zben", "mozg�s nem szomsz�dos ter�letre",
				"felszerel�s lev�tel/eldob�s", "b�n�t� l�ptet�se", "vitust�nc l�ptet�se", "felejt� l�ptet�se", "v�d� l�ptet�se", "nem l�tez� �gens ken�se",
				"lop�s nem b�nult j�t�kost�l","lop�s b�nultan", "lop�s b�nult j�t�kost�l, akinek nincsen anyaga se felszerel�se","lop�s b�nult virol�gust�l, akinek van aminoja", "lop�s b�nult virol�gust�l, akinek van nukleotidja",
				"lop�s b�nult virol�gust�l, akinek van nukleotidja �s �n tele vagyok", "lop�s b�nult virol�gust�l, akin van keszty�", "lop�s b�nult virol�gust�l, akinek van keszty�je az inventory-ban", "lop�s b�nult virol�gust�l, akin  van k�peny",
				"lop�s b�nult virol�gust�l, akinek  van k�penye az inventory-ban", "lop�s b�nult virol�gust�l, akin van zs�k, ami �res", "lop�s b�nult virol�gust�l, akin van zs�k, ami nem �res", "lop�s b�nult virol�gust�l, akinen van zs�kja az inventory-ban"
		};
		for(int i=0;i<str.length;i++) {
			System.out.println(i+" : "+str[i]);
		}
		System.out.println("A program egy Q karakter megad�s�ig fut.");
		String s=" ";
		while(!s.toUpperCase().equals("Q")) {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			s = br.readLine();
			switch (s) {
			case "0": CreatingParalysis();
				break;
			case "1": CreatingVitusDance();
				break;
			case "2": CreatingImmunity();
				break;
			case "3": TakeOffGlovesBackToInventoty();
				break;	
			case "4": TakeOffCloakBackToInventoty();
				break;
			case "5": TakeOffSackBackToInventoty();
				break;
			case "6": TakeOffGlovesAndDrop();
				break;
			case "7": TakeOffCloakAndDrop();
				break;	
			case "8": TakeOffSackAndDrop();
				break;
			case "9": UseAgentOnVirologistWhoHasGlovesAndCloakAndParalyzed();
				break;
			case "10": UseAgentWhileParalyzed();
				break;
			case "11": UseParalysisOnNotImmunVirologist();
				break;
			case "12": UseImmunityOnNotImmunVirologist();
				break;
			case "13": UseOblivionOnNotImmunVirologist();
				break;
			case "14": UseAgentOnVirologistWhoHasCloak();
				break;
			case "15": UseAgentOnVirologistWhoHasImmunity();
				break;
			case "16": UseAgentOnVirologistWhoHasGloves();
				break;
			case "17": UseAgentOnVirologistWhoHasGlovesAndCloak();
				break;
			case "18": UseAgentOnVirologistWhoHasGlovesAndIHaveToo();
				break;
			case "19": UseAgentOnVirologistWhoHasGlovesAndIHaveCloak();
				break;
			case "20": UseAgentOnVirologistWhoHasGlovesAndIHaveImmunity();
				break;
			case "21": SelfuseAgentWhenHasCloak();
				break;
			case "22": SelfuseAgentWhenHasGloves();
				break;
			case "23": SelfuseAgentWhenHasCloakAndGloves();
				break;
			case "24": SelfuseAgentWhenHasNoAgents();
				break;
			case "25": SelfuseAgentWhenParalyzed();
				break;
			case "26": SelfuseAgentWhenHasImmunity();
				break;
			case "27": SelfuseOblivion();
				break;
			case "28": SelfuseVitusDance();
				break;
			case "29": SelfuseImmunity();
				break;
			case "30": SelfuseParalysis();
				break;
			case "31": MoveWhileDancing();
				break;
			case "32": MoveToNotNeighbour();
				break;
			case "33": VirologistMoves();
				break;
			case "34": VirologistMovesParalyzed();
				break;
			case "35": ParalyzedTouchy();
				break;
			case "36": NewGCTouchy();
				break;
			case "37": OldGCTouchy();
				break;
			case "38": WinGameByLastTouchy();
				break;
			case "39": ParalyzedPickUpMat();
				break;
			case "40": NukleoPickUp();
				break;
			case "41": AminoPickUp();
				break;
			case "42": FullPickUpMat();
				break;
			case "43": ParalyzedPickUpEq();
				break;
			case "44": GlovesPickUp();
				break;
			case "45": CloakPickUp();
				break;
			case "46": SackPickUp();
				break;
			case "47": FullPickUpEq();
				break;
			case "48": CreatingOblivion();
				break;
			case "49": DanceWhileMove();
				break;
			case "50": MoveToNowhere();
				break;
			case "51": TakeOnOffEq();
				break;
			case "52": StepParalyzed();
				break;
			case "53": StepVitusDance();
				break;
			case "54": StepOblivion();
				break;
			case "55": StepImmunity();
				break;
			case "56": UseUnavailableAgent();
				break;
			case "57": StealFromNonParalyzed();
				break;
			case "58": StealAsParalyzed();
				break;
			case "59": StealFromPoorGuy();
				break;
			case "60": StealFromAminoGuy();
				break;
			case "61": StealFromNukleoGuy();
				break;
			case "62": StealFromNukleoGuyButIAmFull();
				break;
			case "63": StealFromGuyWithGlovesEquipped();
				break;
			case "64": StealFromGuyWithGlovesInStorage();
				break;
			case "65": StealFromGuyWithCloakEquipped();
				break;
			case "66": StealFromGuyWithCloakInStorage();
				break;
			case "67": StealFromGuyWithEmptySackEquipped();
				break;
			case "68": StealFromGuyWithStuffInSackEquipped();
				break;
			case "69": StealFromGuyWithSackInStorage();
				break;
			default:
			}
		}
	}
	
}
