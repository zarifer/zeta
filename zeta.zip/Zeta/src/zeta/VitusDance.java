/**
 * 
 */
package zeta;

import java.util.ArrayList;
import java.util.Random;

/**
 * @author cloud
 *
 */
public class VitusDance extends Agent
{
	public VitusDance() 
	{
		Logger.enterFunction("VitusDance.VitusDance()");
		
		name = "VitusDance";
		effectTime = 6;
		
		Logger.leaveFunction();
	}
	
	public VitusDance(String name, int remainingTime, int effectTime) 
	{
		Logger.enterFunction("VitusDance.VitusDance(String name, int remainingTime, int effectTime)");
		
		this.name = name;
		this.remainingTime = remainingTime;
		this.effectTime = effectTime;
		
		Logger.leaveFunction();
	}
	@Override
	public void step()
	{
		Logger.enterFunction("VitusDance.step()");
		
		if(virologistUnderEffect != null) 
		{
			System.out.println("Has effect on a virologist");
			virologistUnderEffect.setDancing(true);
			setRemainingTime(remainingTime - 1);
			Field f1 = virologistUnderEffect.getStandingField();
			ArrayList<Field> neighbours = f1.getNeighbours();
			Random r = new Random();
			if (neighbours.size() > 0)
			{
				int x = r.nextInt(neighbours.size());
				
				Field f2=neighbours.get(x);
				
				virologistUnderEffect.move(f2, false);
			}
			
			if(remainingTime==0) {
				System.out.println("Timer ends");
				virologistUnderEffect.setDancing(false);
			}
			
		}
		
		Logger.leaveFunction();
	}

}
