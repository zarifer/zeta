package zeta;

/**
 * The interface for all the steppable objects.
 */
public interface Steppable {
	
	public void step();
}
