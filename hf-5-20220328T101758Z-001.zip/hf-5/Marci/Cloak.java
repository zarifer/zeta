/**
 * 
 */
package zeta;

import java.util.Random;

/**
 * @author cloud
 *
 */
public class Cloak extends Equipment
{
	private double evadePercentage;
	public Cloak() 
	{
		Logger.enterFunction("Cloak.Cloak()");
		evadePercentage = 0.823;
		Logger.leaveFunction();
	}
	
	public void setEvadePercentage(double n)
	{
		Logger.enterFunction("Cloak.setEvadePercentage(double n)");
		
		this.evadePercentage = n;
		
		Logger.leaveFunction();
		
	}
	
	public double getEvadePercentage() 
	{
		Logger.enterFunction("Cloak.getEvadePercentage()");
	
		
		Logger.leaveFunction();
		
		return evadePercentage;
		
	}
	@Override
	public void pickUp(Virologist v) 
	{
		Logger.enterFunction("Cloak.pickUp(Virologist v)");
		
		//TODO
		
		Logger.leaveFunction();
	}
	
	/*
	 * Generates a random number between 1-1000, if it is less than the evadePercent*1000+1 returns true.
	 * If if it greater return false.
	 * */
	public boolean evade()
	{
		Logger.enterFunction("Cloak.evade()");
		
		boolean evadeSuccess = false;
		
		Random r = new Random();
		
		int x = r.nextInt(1000)+1;
		
		if(x < evadePercentage*1000+1) {
			evadeSuccess = true;
			Logger.enterFunction("Evade Successful");
		}
		else {
			evadeSuccess = false;
			Logger.enterFunction("Evade Failed");
		}
		
		Logger.leaveFunction();
		
		return evadeSuccess;
	}
	
}
