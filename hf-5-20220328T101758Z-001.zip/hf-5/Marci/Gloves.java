/**
 * 
 */
package zeta;

import java.io.IOException;

/**
 * @author cloud
 *
 */
public class Gloves extends Equipment{
	
	public Gloves() 
	{
		Logger.enterFunction("Gloves.Gloves()");
		
		Logger.leaveFunction();
	}
	@Override
	public void pickUp(Virologist v)
	{
		Logger.enterFunction("Gloves.pickUp(Virologist v)");
		
		v.getInventory().addGloves(this);
		
		Logger.leaveFunction();
	}
	
	public void use(Virologist vFr, Virologist vTo, Agent a) 
	{
		Logger.enterFunction("Gloves.use(Virologist vFr, Virologist vTo, Agent a)");
		
		vTo.attack(vFr, a);
		
		Logger.leaveFunction();
	}
	
	public boolean wannaUse() 
	{
		Logger.enterFunction("Gloves.wannaUse()");
		
		boolean wannaUse = false;
		
		System.out.println("Wanna use Gloves? (Y/N)");
		int str=' ';
		while(true) {
			try {
				str = System.in.read();
			} catch (IOException e) {
				e.printStackTrace();
			}
			if((char)str=='Y' || (char)str=='y' || (char)str=='N' || (char)str=='n')
				break;
		}
		if((char)str=='Y' || (char)str=='y') {
			wannaUse=true;
			System.out.println("Wants to use Gloves");
		}
		else {
			wannaUse=false;
			System.out.println("Does not want to use Gloves");
		}
		
		Logger.leaveFunction();
		
		return wannaUse;
	}
}
