package zeta;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

public class Program {
	
	public static void CreatingParalysis() {
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		GCode gc = new GCode("Paralysis",1,1);
		v.getInventory().learnGCode(gc);
		v.createAgent(gc);
	}
	
	public static void CreatingVitusDance() {
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		GCode gc = new GCode("VitusDance",1,1);
		v.getInventory().learnGCode(gc);
		v.createAgent(gc);
	}
	
	public static void CreatingImmunity() {
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		GCode gc = new GCode("Immunity",1,1);
		v.getInventory().learnGCode(gc);
		v.createAgent(gc);
	}
	
	public static void TakeOffGlovesBackToInventoty() {
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		Gloves glov = new Gloves();
		v.getInventory().addGloves(glov);
		v.equipGloves();
		v.takeOffGloves();
	}
	
	public static void TakeOffCloakBackToInventoty() {
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		Cloak cloak = new Cloak();
		v.getInventory().addCloak(cloak);
		v.equipCloak();
		v.takeOffCloak();
	}
	
	public static void TakeOffSackBackToInventoty() {
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		Sack sack = new Sack();
		v.getInventory().addSack(sack);
		v.equipSack();
		v.takeOffSack();
	}
	
	public static void TakeOffGlovesAndDrop() {
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		Gloves glov = new Gloves();
		v.getInventory().addGloves(glov);
		v.equipGloves();
		Inventory inv = v.getInventory();
		for(int i=0; i<5;i++) {
			Sack s = new Sack();
			inv.addSack(s);
		}
		v.takeOffGloves();
	}
	
	public static void TakeOffCloakAndDrop() {
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		Cloak cloak = new Cloak();
		v.getInventory().addCloak(cloak);
		v.equipCloak();
		Inventory inv = v.getInventory();
		for(int i=0; i<5;i++) {
			Sack s = new Sack();
			inv.addSack(s);
		}
		v.takeOffCloak();
	}
	
	public static void TakeOffSackAndDrop() {
		Game g = new Game();
		Field f = new Field();
		Virologist v = new Virologist(g,f);
		Sack sack = new Sack();
		v.getInventory().addSack(sack);
		v.equipSack();
		Inventory inv = v.getInventory();
		for(int i=0; i<5;i++) {
			Gloves glov = new Gloves();
			inv.addGloves(glov);
		}
		v.takeOffSack();
	}
	
	public static void UseAgentOnVirologistWhoHasGlovesAndCloakAndParalyzed(){
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		Gloves glov=new Gloves();
		v2.getInventory().addGloves(glov);
		v2.equipGloves();
		Cloak cloak=new Cloak();
		v2.getInventory().addCloak(cloak);
		v2.equipCloak();
		v2.setParalyzed(true);
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseAgentWhileParalyzed() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		v1.setParalyzed(true);
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseParalysisOnNotImmunVirologist() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		v2.setImmunity(false);
		Paralysis o=new Paralysis();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseImmunityOnNotImmunVirologist() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		v2.setImmunity(false);
		Immunity i=new Immunity();
		v1.addAgent(i);
		v1.attack(v2, i);
	}
	
	public static void UseOblivionOnNotImmunVirologist() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		v2.setImmunity(false);
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseAgentOnVirologistWhoHasCloak() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		Cloak cloak=new Cloak();
		v2.getInventory().addCloak(cloak);
		v2.equipCloak();
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseAgentOnVirologistWhoHasImmunity() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		v2.setImmunity(true);
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseAgentOnVirologistWhoHasGloves() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		Gloves glov=new Gloves();
		v2.getInventory().addGloves(glov);
		v2.equipGloves();
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseAgentOnVirologistWhoHasGlovesAndCloak() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		Gloves glov=new Gloves();
		v2.getInventory().addGloves(glov);
		v2.equipGloves();
		Cloak cloak=new Cloak();
		v2.getInventory().addCloak(cloak);
		v2.equipCloak();
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseAgentOnVirologistWhoHasGlovesAndIHaveToo() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		Gloves glov2=new Gloves();
		v2.getInventory().addGloves(glov2);
		v2.equipGloves();
		Gloves glov1=new Gloves();
		v1.getInventory().addGloves(glov1);
		v1.equipGloves();
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseAgentOnVirologistWhoHasGlovesAndIHaveCloak() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		Gloves glov=new Gloves();
		v2.getInventory().addGloves(glov);
		v2.equipGloves();
		Cloak cloak=new Cloak();
		v2.getInventory().addCloak(cloak);
		v2.equipCloak();
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void UseAgentOnVirologistWhoHasGlovesAndIHaveImmunity() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Virologist v2 = new Virologist(g,f);
		Gloves glov=new Gloves();
		v2.getInventory().addGloves(glov);
		v2.equipGloves();
		v1.setImmunity(true);
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v2, o);
	}
	
	public static void SelfuseAgentWhenHasCloak() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Cloak cloak=new Cloak();
		v1.getInventory().addCloak(cloak);
		v1.equipCloak();
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v1, o);
	}
	
	public static void SelfuseAgentWhenHasGloves() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Gloves glov=new Gloves();
		v1.getInventory().addGloves(glov);
		v1.equipGloves();
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v1, o);
	}
	
	public static void SelfuseAgentWhenHasCloakAndGloves() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Cloak cloak=new Cloak();
		v1.getInventory().addCloak(cloak);
		v1.equipCloak();
		Gloves glov=new Gloves();
		v1.getInventory().addGloves(glov);
		v1.equipGloves();
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v1, o);
	}
	
	public static void SelfuseAgentWhenHasNoAgents() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		v1.attack(v1, new Oblivion());
	}
	
	public static void SelfuseAgentWhenParalyzed() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		v1.setParalyzed(true);
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v1, o);
	}
	
	public static void SelfuseAgentWhenHasImmunity() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		v1.setImmunity(true);
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v1, o);
	}
	
	public static void SelfuseOblivion() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Oblivion o=new Oblivion();
		v1.addAgent(o);
		v1.attack(v1, o);
	}
	
	public static void SelfuseVitusDance() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		VitusDance o=new VitusDance();
		v1.addAgent(o);
		v1.attack(v1, o);
	}
	
	public static void SelfuseImmunity() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Immunity o=new Immunity();
		v1.addAgent(o);
		v1.attack(v1, o);
	}
	
	public static void SelfuseParalysis() {
		Game g = new Game();
		Field f = new Field();
		Virologist v1 = new Virologist(g,f);
		Paralysis o=new Paralysis();
		v1.addAgent(o);
		v1.attack(v1, o);
	}
	
	public static void MoveWhileDancing() {
		Game g = new Game();
		Field f1 = new Field();
		Virologist v1 = new Virologist(g,f1);
		v1.setDancing(true);
		Field f2 = new Field();
		v1.move(f2);
	}
	
	public static void MoveToNotNeighbour() {
		Game g = new Game();
		Field f1 = new Field();
		Virologist v1 = new Virologist(g,f1);
		Field f2 = new Field();
		v1.move(f2);
	}
	
	
	public static void main(String[] args) throws IOException
	{
		System.out.println("Zeta Csapat Szkeleton\n");
		System.out.println("Lehets�ges UseCase-k:");
		String str[]= {"b�n�t� �gens k�sz�t�se","t�ncol� �gens k�sz�t�se","v�d� �gens k�sz�t�se","keszty� lev�tel, vissza az inventoryba","k�peny lev�tel, vissza az inventoryba", "zs�k lev�tel, vissza az inventoryba",
				"keszty� lev�tel,de az inventory tele van","k�peny lev�tel,de az inventory tele van", "zs�k lev�tel,de az inventory tele van", "�gens ken�se b�nult k�penyes keszty�s virol�gusra","�gens ken�se m�sra b�nultan",
				"b�n�t� �gens ken�se v�dtelen virol�gusra","v�d� �gens ken�se v�dtelen virol�gusra","felejt� �gens ken�se v�dtelen virol�gusra","�gens ken�se k�penyes virol�gusra","�gens ken�se v�d� �genses virol�gusra",
				"�gens ken�se keszty�s virol�gusra","�gens ken�se k�penyes �s keszty�s virol�gusra","�gens ken�se keszty�s virol�gusra mikor nekem is van keszty�m (nekem legal�bb annyi van, mint neki)",
				"�gens ken�se keszty�s virol�gusra mikor rajtam k�peny van","�gens ken�se keszty�s virol�gusra mikor rajtam v�d� �gens van","�gens magamra ken�se mikor k�peny van rajtam","�gens magamra ken�se mikor keszty� van rajtam",
				"�gens magamra ken�se mikor keszty� �s k�peny van rajtam","�gens magamra ken�se mikor nincs olyan �gensem","�gens ken�se b�nultan �nmag�ra","�gens ken�se magamra v�d��gens hat�sa alatt","b�n�t� �gens ken�se magamra",
				"t�ncol� �gens ken�se magamra","v�d� �gens ken�se magamra","felejt� �gens ken�se magamra"};
		for(int i=0;i<str.length;i++) {
			System.out.println(i+" : "+str[i]);
		}
		System.out.println("A program egy Q karakter megad�s�ig fut.");
		String s=" ";
		while(!s.toUpperCase().equals("Q")) {
			BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
			s = br.readLine();
			switch (s) {
			case "0": CreatingParalysis();
				break;
			case "1": CreatingVitusDance();
				break;
			case "2": CreatingImmunity();
				break;
			case "3": TakeOffGlovesBackToInventoty();
				break;	
			case "4": TakeOffCloakBackToInventoty();
				break;
			case "5": TakeOffSackBackToInventoty();
				break;
			case "6": TakeOffGlovesAndDrop();
				break;
			case "7": TakeOffCloakAndDrop();
				break;	
			case "8": TakeOffSackAndDrop();
				break;
			case "9": UseAgentOnVirologistWhoHasGlovesAndCloakAndParalyzed();
				break;
			case "10": UseAgentWhileParalyzed();
				break;
			case "11": UseParalysisOnNotImmunVirologist();
				break;
			case "12": UseImmunityOnNotImmunVirologist();
				break;
			case "13": UseOblivionOnNotImmunVirologist();
				break;
			case "14": UseAgentOnVirologistWhoHasCloak();
				break;
			case "15": UseAgentOnVirologistWhoHasImmunity();
				break;
			case "16": UseAgentOnVirologistWhoHasGloves();
				break;
			case "17": UseAgentOnVirologistWhoHasGlovesAndCloak();
				break;
			case "18": UseAgentOnVirologistWhoHasGlovesAndIHaveToo();
				break;
			case "19": UseAgentOnVirologistWhoHasGlovesAndIHaveCloak();
				break;
			case "20": UseAgentOnVirologistWhoHasGlovesAndIHaveImmunity();
				break;
			case "21": SelfuseAgentWhenHasCloak();
				break;
			case "22": SelfuseAgentWhenHasGloves();
				break;
			case "23": SelfuseAgentWhenHasCloakAndGloves();
				break;
			case "24": SelfuseAgentWhenHasNoAgents();
				break;
			case "25": SelfuseAgentWhenParalyzed();
				break;
			case "26": SelfuseAgentWhenHasImmunity();
				break;
			case "27": SelfuseOblivion();
				break;
			case "28": SelfuseVitusDance();
				break;
			case "29": SelfuseImmunity();
				break;
			case "30": SelfuseParalysis();
				break;
			case "43": MoveWhileDancing();
				break;
			case "44": MoveToNotNeighbour();
				break;
			default:
			}
		}
	}
	
}
