package zeta;
import java.io.IOException;

/** 
 * This class is one of the inheritors or heirs of the Field class, that is why we apply the extends expression here.
 * The purpose of this field is to "store" the gcode in the game.
 */
public class Lab extends Field{

	/** 
	 * The GCName variable is the actual name of the GCode.
	 */
	private GCode gc;
	
	/** 
	 * The constructor for this class. We initialize the variable here.
	 * 
	 * @param gcname, am, nuk
	 */
	public Lab(String gcname, int am, int nuk)
	{
		Logger.enterFunction("Lab.Lab()");
		
		gc = new GCode(gcname, am, nuk);
		
		Logger.leaveFunction();
	}
	
	/** 
	 * The method deals with the available action on this type of field, like calling the base class's arrive
	 * and the touchy and so on.
	 * 
	 * @param v
	 */
	public void arrive(Virologist v)
	{
		Logger.enterFunction("Lab.arrive(Virologist v)");
		
		boolean b = false;
		
		super.arrive(v);
		arrive(v);
		
		b = wannaTouchy();
		
		if (!b)
		{
			v.touchy(gc);
		}
		
		Logger.leaveFunction();
	}
	
	/** 
	 * The method asks the user, that if one wants to read the available code there or not.
	 * 
	 * @return the return is a boolean type value, which depends on the users input
	 */
	private boolean wannaTouchy()
	{
		Logger.enterFunction("Lab.wannaTouchy()");
		
		boolean b = false;
		int str=' ';
		
		System.out.println("Akarsz kodot leolvasni? (Y/N)");
		
		while(true) 
		{
			try 
			{
				str = System.in.read();
				
			} catch (IOException e) 
			
			{
				e.printStackTrace();
			}
			
			if ((char)str == 'Y' || (char)str == 'y' || (char)str == 'N' || (char)str == 'n')
				break;
		}
		
		if (str == 'y' || str == 'Y') 
		{
			Logger.enterFunction("Choose to learn GCode.");
			b = true;
		}
		
		else
			Logger.enterFunction("Choose not to learn GCode.");
		
		Logger.leaveFunction();
		
		return b;
	}
}
