package zeta;
import java.io.IOException;
import java.util.ArrayList;

/** 
 * This is the base class for the fields like Storage, Lab and Shelter and works also the basic field.
 */
public class Field {

	private ArrayList<Field> Neighbours;
	private ArrayList<Virologist> Viros;
	
	/** 
	 * The constructor for this class. We initialize the variables here.
	 */
	public Field()
	{
		Logger.enterFunction("Field.Field()");
		
		Neighbours = new ArrayList<Field>(1);
		Viros = new ArrayList<Virologist>(0);
		
		Logger.leaveFunction();
	}
	
	/** 
	 * This is a setter method which sets the current field's Neighbours.
	 * This looks like this only for the skeleton demo.
	 * 
	 * @param f
	 */
	public void setNeighbours(Field f1, Field f2)
	{
		Logger.enterFunction("Field.setNeighbours()");
		
		if (f1 != null && f2 != null)
		{
			f1.Neighbours.add(f2);
		}
		
		Logger.leaveFunction();
		
	}
	
	/** 
	 * This is a getter method which gives you back the list of virologists
	 * who stand on the current field.
	 * 
	 * @return the return is a list of array, which gives you back a list of virologists
	 */
	public ArrayList<Virologist> getVirologists()
	{
		Logger.enterFunction("Field.getVirologists()");
		Logger.leaveFunction();
		
		return Viros;
	}
	
	/** 
	 * This is a getter method which gives you back the current field's Neighbours.
	 * 
	 * @return the return is a list of array, which gives you back the neighbours fields
	 */
	public ArrayList<Field> getNeighbours()
	{
		Logger.enterFunction("Field.getNeighbours()");
		Logger.leaveFunction();
		
		return Neighbours;
	}
	
	/** 
	 * The method deals with the available action on this type of field, like calling the base class's arrive
	 * and the wannaSteal and so on.
	 * 
	 * @param v
	 */
	public void arrive(Virologist v)
	{
		Logger.enterFunction("Field.arrive(Virologist v)");
		boolean b = false;

		b = wannaSteal(b);
		
		if (!b)
		{
			v.stealBy(v);
		}
		
		Logger.leaveFunction();
	}
	
	/** 
	 * This method asks the user, that if one wants to steal from a paralyzed player.
	 * 
	 * @param b
	 * @return the return is a boolean type value, which depends on the users input
	 */
	private boolean wannaSteal(boolean b)
	{
		Logger.enterFunction("Field.wannaSteal()");
		
		b = false;
		int str=' ';
		
		System.out.println("Akarsz lopni? (Y/N)");
		
		while(true) 
		{
			try 
			{
				str = System.in.read();
				
			} catch (IOException e) 
			
			{
				e.printStackTrace();
			}
			
			if ((char)str == 'Y' || (char)str == 'y' || (char)str == 'N' || (char)str == 'n')
				break;
		}
		
		if (str == 'y' || str == 'Y') 
		{
			Logger.enterFunction("Choose to steal.");
			b = true;
		}
		
		else
			Logger.enterFunction("Choose not to steal.");
		
		Logger.leaveFunction();
		
		return b;
	}
	
	/** 
	 * This method adds the newcomer virologist to the current field's virologist list.
	 * 
	 * @param v
	 */
	public void addVirologist(Virologist v)
	{
		Logger.enterFunction("Field.addVirologist(Virologist v)");
		
		Viros.add(v);
		
		Logger.leaveFunction();
	}
	
	/** 
	 * This method removes the passing virologist from the current field's virologist list.
	 * 
	 * @param v
	 */
	public void removeVirologist(Virologist v)
	{
		Logger.enterFunction("Field.removeVirologist(Virologist v)");
		
		Viros.remove(v);
		
		Logger.leaveFunction();
	}
	
}
