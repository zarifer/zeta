package zeta;
import java.io.IOException;
import java.util.Random;

/** 
 * This class is one of the inheritors or heirs of the Field class, that is why we apply the extends expression here.
 * The purpose of this field is to "store" the materials on one field.
 */
public class Shelter extends Field{

	/** 
	 * The constructor for this class.
	 */
	public Shelter()
	{
		Logger.enterFunction("Shelter.Shelter()");
		Logger.leaveFunction();
	}

	/** 
	 * The method deals with the available action on this type of field, like calling the base class's arrive
	 * and the pickup and so on.
	 * 
	 * @param v
	 */
	public void arrive(Virologist v)
	{
		Logger.enterFunction("Shelter.arrive(Virologist v)");
		
		boolean b = false;
		
		super.arrive(v);
		arrive(v);
		
		b = wannaPickUp();
		
		if (!b)
		{
			addMat(v);
		}
		
		Logger.leaveFunction();
	}
	
	/** 
	 * This method creates the material by using a random number generator from 0 to 1 and calls the 
	 * correspondent pickup method of it.
	 * 
	 * @param v
	 */
	private void addMat(Virologist v)
	{
		Logger.enterFunction("Shelter.addMat(Virologist v)");
		
		Aminoacid a = new Aminoacid();
		Nukleotid n = new Nukleotid();
		Random r = new Random();
		int x = r.nextInt(1);
		
		switch(x)
		{
			case 0:
				a.pickUp(v);
				break;
				
			case 1:
				n.pickUp(v);
				break;
		}
		
		Logger.leaveFunction();
	}
	
	/** 
	 * This method asks the user, that if one wants to pick up the available materials there or not.
	 * 
	 * @return the return is a boolean type value, which depends on the users input
	 */
	private boolean wannaPickUp()
	{
		Logger.enterFunction("Shelter.wannaPickUp()");
		
		boolean b = false;
		int str=' ';
		
		System.out.println("Akarsz anyagot felvenni? (Y/N)");
		
		while(true) 
		{
			try 
			{
				str = System.in.read();
				
			} catch (IOException e) 
			
			{
				e.printStackTrace();
			}
			
			if ((char)str == 'Y' || (char)str == 'y' || (char)str == 'N' || (char)str == 'n')
				break;
		}
		
		if (str == 'y' || str == 'Y') 
		{
			Logger.enterFunction("Choose to pick up a material.");
			b = true;
		}
		
		else
			Logger.enterFunction("Choose not to not pick up a material.");
		
		Logger.leaveFunction();
		
		return b;
	}
}
