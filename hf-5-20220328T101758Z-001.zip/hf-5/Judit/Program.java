package zeta;
import zeta.Logger;

public class Program {
	
	public static void main(String[] args) 
	{
		//by entering function always call Logger.enterfunction()
		//before return always call Logger.leaveFunction()!!!!!!!!!!!!!!!!
		Logger.enterFunction("Timer.step()");
		Logger.enterFunction("Virologist.setImmunity()");
		Logger.leaveFunction();
		Logger.enterFunction("Immunity.setRemainingTime()");
		Logger.leaveFunction();
		Logger.enterFunction("Virologist.setImmunity()");
		Logger.enterFunction("Virologist.die()");
		Logger.leaveFunction();
		Logger.enterFunction("Virologist.revive()");
		Logger.leaveFunction();
		Logger.leaveFunction();
		Logger.enterFunction("Virologist.setHasEffectedAgent()");
		Logger.leaveFunction();
		Logger.leaveFunction();
		Logger.enterFunction("newfuction()");
		Logger.leaveFunction();
	}
	
}
