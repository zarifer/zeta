package zeta;
import java.util.ArrayList;

public class Inventory {
	private int maxMaterial;
	private static final int maxEquipment = 5;
	private ArrayList<Gloves> storedGloves;
	private ArrayList<Sack> storedSacks;
	private ArrayList<Cloak> storedCloaks;
	private ArrayList<GCode> learntGCode;
	private ArrayList<Aminoacid> aminos;
	private ArrayList<Nukleotid> nukleotids;
	
	public Inventory()
	{
		Logger.enterFunction("Inventory.Inventory()");
		
		storedGloves = new ArrayList<Gloves>();
		storedSacks = new ArrayList<Sack>();
		storedCloaks = new ArrayList<Cloak>();
		learntGCode = new ArrayList<GCode>();
		aminos = new ArrayList<Aminoacid>();
		nukleotids = new ArrayList<Nukleotid>();
		maxMaterial = 20;
		
		Logger.leaveFunction();
	}
	
	public Inventory(ArrayList<Gloves> storedGloves, ArrayList<Sack> storedSacks, ArrayList<Cloak> storedCloaks,
			ArrayList<GCode> learntGCode, ArrayList<Aminoacid> aminos, ArrayList<Nukleotid> nukleotids)
	{
		Logger.enterFunction("Inventory.Inventory(ArrayList<Gloves> storedGloves, ArrayList<Sack> storedSacks, ArrayList<Cloak> storedCloaks, ArrayList<GCode> learntGCode, ArrayList<Aminoacid> aminos, ArrayList<Nukleotid> nukleotids)");
		
		this.storedGloves = storedGloves;
		this.storedSacks = storedSacks;
		this.storedCloaks = storedCloaks;
		this.learntGCode = learntGCode;
		this.aminos = aminos;
		this.nukleotids = nukleotids;
		maxMaterial = 20;
		
		Logger.leaveFunction();
	}
	
	
	public void setMaxMaterial(int maxMaterial)
	{
		Logger.enterFunction("Inventory.setMaxMaterial(int maxMaterial = " + Integer.toString(maxMaterial) + ")");
		
		if (this.maxMaterial > maxMaterial)
		{
			int overFlow = aminos.size() + nukleotids.size() - maxMaterial;
			if (overFlow > 0)
			{
				if (aminos.size() > nukleotids.size())
				{
					for (int i=0; i<overFlow; i++)
					{
						aminos.remove(0);
					}
					System.out.println(Integer.toString(overFlow) + " aminoacids dropped from inventory.");
				}
				else 
				{
					for (int i=0; i<overFlow; i++)
					{
						nukleotids.remove(0);
					}
					System.out.println(Integer.toString(overFlow) + " nukleotids dropped from inventory.");
				}
			}
		}
		
		this.maxMaterial = maxMaterial;
		
		Logger.leaveFunction();
	}
	
	public int getMaxMaterial()
	{
		Logger.enterFunction("Inventory.getMaxMaterial()");
		Logger.leaveFunction();
		
		return maxMaterial;
	}
	
	public void addGloves(Gloves g)
	{
		Logger.enterFunction("Inventory.addGloves(Gloves g)");
		
		if (g == null)
		{
			System.out.println("Null object can not be added.");
		}
		else if (canAddEq())
		{
			storedGloves.add(g);
			System.out.println("Gloves added to inventory.");
		}
		
		Logger.leaveFunction();
	}
	
	public void addSack(Sack s)
	{
		Logger.enterFunction("Inventory.addSack(Sack s)");
		
		if (s == null)
		{
			System.out.println("Null object can not be added.");
		}
		else if (canAddEq())
		{
			storedSacks.add(s);
			System.out.println("Sack added to inventory.");
		}
		
		Logger.leaveFunction();
	}
	
	public void addCloak(Cloak c)
	{
		Logger.enterFunction("Inventory.addCloak(Cloak c)");
		
		if (c == null)
		{
			System.out.println("Null object can not be added.");
		}
		else if (canAddEq())
		{
			storedCloaks.add(c);
			System.out.println("Cloak added to inventory.");
		}
		
		Logger.leaveFunction();
	}
	
	public Gloves removeGloves()
	{
		Logger.enterFunction("Inventory.removeGloves()");
		
		Gloves g = null;
		if (storedGloves.size() > 0)
		{
			g = storedGloves.remove(0);
			System.out.println("Taking out 1 gloves from inventory.");
		}
		else
		{
			System.out.println("No gloves found to take off.");
		}
		
		Logger.leaveFunction();
		return g;
	}
	
	public Sack removeSack()
	{
		Logger.enterFunction("Inventory.removeSack()");
		
		Sack s = null;
		if (storedSacks.size() > 0)
		{
			s = storedSacks.remove(0);
			System.out.println("Taking out 1 sack from inventory.");
		}
		else
		{
			System.out.println("No sack found to take off.");
		}
		
		Logger.leaveFunction();
		return s;
	}
	
	public Cloak removeCloak()
	{
		Logger.enterFunction("Inventory.removeCloak()");
		
		Cloak c = null;
		if (storedCloaks.size() > 0)
		{
			c = storedCloaks.remove(0);
			System.out.println("Taking out 1 cloak from inventory.");
		}
		else
		{
			System.out.println("No cloak found to take off.");
		}
		
		Logger.leaveFunction();
		return c;
	}
	
	//it is enough to give over the GCode here, don't need to use the Lab object inside this function
	public int learnGCode(GCode g)
	{
		Logger.enterFunction("Inventory.learnGCode(GCode g)");
		
		if (!learntGCode.contains(g) && g != null)
		{
			learntGCode.add(g);
			System.out.println("New genetic code: " + g.getGCName() + ".");
		}
		else
		{
			System.out.println("Genetic code: " + g.getGCName() + " was already learnt.");
		}
		
		Logger.leaveFunction();
		
		//instead of returning a boolean value representing, if we learnt a new code,
		//we return the size of lertGCode, which can be used directly for checking if we have all code learnt.
		return learntGCode.size();
	}
	
	public void forgetGCodes()
	{
		Logger.enterFunction("Inventory.forgetGCodes()");
		
		learntGCode.clear();
		System.out.println("All code forgotten.");
		
		Logger.leaveFunction();
	}
	
	public void addAmino(Aminoacid am)
	{
		Logger.enterFunction("Inventory.addAmino(AminoAcid am)");
		if (am == null)
		{
			System.out.println("Null object can not be added.");
		}
		else if (canAddMaterial())
		{
			aminos.add(am);
			System.out.println("Aminoacid added to inventory.");
		}
		
		Logger.leaveFunction();
	}
	
	public void addNukleo(Nukleotid n)
	{
		Logger.enterFunction("Inventory.addNukleo(Nukleotid n)");
		
		if (n == null)
		{
			System.out.println("Null object can not be added.");
		}
		else if (canAddMaterial())
		{
			nukleotids.add(n);
			System.out.println("Nukleotid added to inventory.");
		}
		
		Logger.leaveFunction();
	}
	
	public Aminoacid removeAmino()
	{
		Logger.enterFunction("Inventory.removeAmino()");
		
		Aminoacid a = null;
		if (aminos.size() > 0)
		{
			a = aminos.remove(0);
			System.out.println("Taking out 1 aminoacid from inventory.");
		}
		else
		{
			System.out.println("No aminoacid found to take off.");
		}
		
		Logger.leaveFunction();
		return a;
	}
	
	public Nukleotid removeNukleo()
	{
		Logger.enterFunction("Inventory.removeNukleo()");
		
		Nukleotid n = null;
		if (nukleotids.size() > 0)
		{
			n = nukleotids.remove(0);
			System.out.println("Taking out 1 nukleotid from inventory.");
		}
		else
		{
			System.out.println("No nukleotid found to take off.");
		}
		
		Logger.leaveFunction();
		return n;
	}
	
	public int getStoredAminoCount()
	{
		Logger.enterFunction("Inventory.getStoredAminoCount()");
		Logger.leaveFunction();
		
		return aminos.size();
	}
	
	public int getStoredNukleotidCount()
	{
		Logger.enterFunction("Inventory.getStoredNukleotidCount()");
		Logger.leaveFunction();
		
		return nukleotids.size();
	}
	
	private boolean canAddEq() 
	{
		Logger.enterFunction("Inventory.canAddEq()");
		
		
		boolean bCanAdd = storedGloves.size() + storedSacks.size() + storedCloaks.size() < maxEquipment;
		if (!bCanAdd)
		{
			System.out.println("There is not enough place in storage to add Equipment.");
		}
		
		Logger.leaveFunction();
		return bCanAdd;
	}
	
	private boolean canAddMaterial()
	{
		Logger.enterFunction("Inventory.canAddMaterial()");
		
		boolean bCanAdd = aminos.size() + nukleotids.size() < maxMaterial;
		if (!bCanAdd)
		{
			System.out.println("There is not enough place in storage to add Material.");
		}
		
		Logger.leaveFunction();
		return bCanAdd;
	}
}
