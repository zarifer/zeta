package zeta;

import java.util.ArrayList;

public class Game {
	
	private final static int maxGCode = 4;
	private ArrayList<Field> fields = new ArrayList<Field>();
	
	public static int getMaxGCode()
	{
		Logger.enterFunction("Game.getMaxGCode()");
		Logger.leaveFunction();
		
		return maxGCode;
	}
	
	public void endGame(Virologist v)
	{
		Logger.enterFunction("Game.endGame(Virologist v)");
		
		if (v != null)
		{
			for (int i = 0; i < fields.size(); i++)
			{
				ArrayList<Virologist> vList = fields.get(i).getVirologists();
				for (int j = 0; j < vList.size(); j++)
				{
					vList.get(j).showEndGame(v);
				}
			}
		}
		
		Logger.leaveFunction();
	}

	public ArrayList<Field> getFields() 
	{
		Logger.enterFunction("Game.getFields()");
		Logger.leaveFunction();
		
		return fields;
	}

	public void setFields(ArrayList<Field> fields)
	{
		Logger.enterFunction("Game.setFields()");
		
		this.fields = fields;
		
		Logger.leaveFunction();
	}
	
}
