/**
 * 
 */
package zeta;

/**
 * @author cloud
 *
 */
public class VitusDance extends Agent
{
	public VitusDance() 
	{
		Logger.enterFunction("VitusDance.VitusDance()");
		
		name = "VitusDance";
		effectTime = 6;
		
		Logger.leaveFunction();
	}
	
	public VitusDance(String name, int remainingTime, int effectTime) 
	{
		Logger.enterFunction("VitusDance.VitusDance(String name, int remainingTime, int effectTime)");
		
		this.name = name;
		this.remainingTime = remainingTime;
		this.effectTime = effectTime;
		
		Logger.leaveFunction();
	}
	@Override
	public void step()
	{
		Logger.enterFunction("VitusDance.step()");
		
		if(virologistUnderEffect != null) 
		{
			virologistUnderEffect.setDancing(true);
			setRemainingTime(remainingTime - 1);
			//getneighbour-os r�sz???
		}
		
		Logger.leaveFunction();
	}

}
