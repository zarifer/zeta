/**
 * 
 */
package zeta;

/**
 * @author cloud
 *
 */
public class Oblivion extends Agent
{
	public Oblivion()
	{
		Logger.enterFunction("Oblivion.Oblivion()");
		
		name = "Oblivion";
		effectTime = 1;
		
		Logger.leaveFunction();
	}
	
	public Oblivion(String name, int remainingTime, int effectTime) 
	{
		Logger.enterFunction("Oblivion.Oblivion(String name, int remainingTime, int effectTime)");
		
		this.name = name;
		this.remainingTime = remainingTime;
		this.effectTime = effectTime;
		
		Logger.leaveFunction();
	}
	
	@Override
	public void step()
	{
		
		Logger.enterFunction("Oblivion.step()");
		
		if(virologistUnderEffect != null)
		{
			Inventory inv = new Inventory();
			inv = virologistUnderEffect.getInventory();
			inv.forgetGCodes();
			//setHasEffected ???
			setRemainingTime(0);
			//removeSteppable();
		}
				
		Logger.leaveFunction();
	}

}
