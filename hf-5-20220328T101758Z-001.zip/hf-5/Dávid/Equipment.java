/**
 * 
 */
package zeta;

/**
 * @author cloud
 *
 */
public abstract class Equipment {
	public Equipment() 
	{
		Logger.enterFunction("Equipment.Equipment()");
		
		//TODO
		
		Logger.leaveFunction();
	}
	
	public void pickUp(Virologist v)
	{
		Logger.enterFunction("Equipment.pickUp()");
		
		//TODO
		
		Logger.leaveFunction();
	}

}
