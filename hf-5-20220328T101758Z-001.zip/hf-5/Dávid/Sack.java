/**
 * 
 */
package zeta;

/**
 * @author cloud
 *
 */
public class Sack extends Equipment
{
	private static final int capacity = 5;
	
	public Sack() 
	{
		Logger.enterFunction("Sack.Sack()");
		Logger.leaveFunction();
	}
	
	@Override
	public void pickUp(Virologist v) 
	{
		Logger.enterFunction("Sack.pickUp()");
		
		//TODO
		v.getInventory().addSack(this);
		
		Logger.leaveFunction();
	}
	
	
	public int getCapacity() 
	{
		Logger.enterFunction("Sack.getCapacity()");
		Logger.leaveFunction();
		
		return capacity;
	}
}
