/**
 * 
 */
package zeta;

/**
 * @author cloud
 *
 */
public abstract class Agent
{
	protected Virologist virologistUnderEffect;
	protected String name;
	protected int remainingTime;
	protected final static int expiration = 10;
	protected int effectTime;
	
	public Agent() 
	{
		Logger.enterFunction("Agent.Agent()");
		
		remainingTime = expiration;
		
		Logger.leaveFunction();
	}
		
	public void step() 
	{
		Logger.enterFunction("Agent.step()");
		
		//TODO
		
		Logger.leaveFunction();
	}
	
	public void setRemainingTime(int remainingTime) 
	{
		Logger.enterFunction("Agent.setRemainingTime(int remainingTime)");
		
		this.remainingTime = remainingTime;
		
		Logger.leaveFunction();
	}
	
	
	public void setEffectTime(int effectTime) 
	{
		Logger.enterFunction("Agent.setEffectTime(int effectTime)");
		
		this.effectTime = effectTime;
		
		Logger.leaveFunction();
	}
	
	public void setName(String s) 
	{
		Logger.enterFunction("Agent.setName()");
		
		this.name = s;
		
		Logger.leaveFunction();
	}
	
	public int getRemainingTime()
	{
		Logger.enterFunction("Agent.getRemainingTime()");
		Logger.leaveFunction();
		
		return remainingTime;
	}
	
	public int getExpiration()
	{
		Logger.enterFunction("Agent.getExpiration()");
		Logger.leaveFunction();
		
		return expiration;
	}
	
	public int getEffectTime()
	{
		Logger.enterFunction("Agent.getEffectTime()");
		Logger.leaveFunction();
		
		return effectTime;
	}
	public String getName() 
	{
		Logger.enterFunction("Agent.getName()");
		Logger.leaveFunction();
		
		return name;
	}
}
