/**
 * 
 */
package zeta;

/**
 * @author cloud
 *
 */
public class Paralysis extends Agent
{
	public Paralysis() 
	{
		Logger.enterFunction("Paralysis.Paralysis()");
		
		name = "Paralysis";
		effectTime = 3;
		
		Logger.leaveFunction();
	}
	
	public Paralysis(String name, int remainingTime, int effectTime) 
	{
		Logger.enterFunction("Paralysis.Paralysis(String name, int remainingTime, int effectTime)");
		
		this.name = name;
		this.remainingTime = remainingTime;
		this.effectTime = effectTime;
		
		Logger.leaveFunction();
	}
	@Override
	public void step()
	{
		Logger.enterFunction("Paralysis.step()");
		
		if(virologistUnderEffect != null) 
		{
			virologistUnderEffect.setParalyzed(true);
			setRemainingTime(remainingTime-1);
			if(remainingTime == 0)
			{
				virologistUnderEffect.setParalyzed(false);
				//setHasEffectedAgent()
				//removeSteppable()
			}
		}		
		Logger.leaveFunction();
	}

}
